import React from 'react'

function News() {
  return (
    <div>
      <h1>News</h1>
    </div>
  )
}

export default News
